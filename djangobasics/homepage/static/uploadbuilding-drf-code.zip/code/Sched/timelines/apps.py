from django.apps import AppConfig


class TimelinesConfig(AppConfig):
    name = "timelines"
