# vehicles/models/tools.py

class Tool:
    def __init__(self, name, make):
        self.name = name
        self.make = make
