from django.apps import AppConfig


class ArtifactsConfig(AppConfig):
    name = "artifacts"
